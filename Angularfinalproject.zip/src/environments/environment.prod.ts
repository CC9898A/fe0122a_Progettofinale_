export const environment = {
  production: true,
  serverurl:"http://epicode.online/epicodebeservice_v2"
};
