export interface clientlist {

  id: number,
  ragioneSociale: string,
  partitaIva: string,
  email: string,
  pec: string,
  telefono: number,
  nomeContatto: string,
  cognomeContatto: string,
  telefonoContatto: number,
  emailContatto: string,





}
