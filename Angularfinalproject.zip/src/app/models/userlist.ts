export interface Userlist {

"id":number,
"username":string,
"email":string,
"roles":[{"id":number,"rolename":string}]








}
