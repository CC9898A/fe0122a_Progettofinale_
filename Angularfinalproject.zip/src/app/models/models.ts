export interface logindate {

"username":string,
"password":string






}
