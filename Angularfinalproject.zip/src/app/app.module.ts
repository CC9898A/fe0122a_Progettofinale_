import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeadernavbarnavComponent } from './headernavbarnav/headernavbarnav.component';
import { LoginuserComponent } from './loginuser/loginuser.component';
import { HttpClientModule } from '@angular/common/http'
import { Component } from '@angular/core';
import { HomecomponentComponent } from './homecomponent/homecomponent.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { InterceptorttokencallInterceptor } from './interceptorttokencall.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserlistComponent } from './userlist/userlist.component';
import { ReguserComponent } from './reguser/reguser.component';
import { ClientComponent } from './client/client.component';
import { FatturacmpComponent } from './fatturacmp/fatturacmp.component';






@NgModule({
  declarations: [
    AppComponent,
    HeadernavbarnavComponent,
    LoginuserComponent,
    UserlistComponent,
    ReguserComponent,
    ClientComponent,
    FatturacmpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,

  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,
    useClass:InterceptorttokencallInterceptor,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
