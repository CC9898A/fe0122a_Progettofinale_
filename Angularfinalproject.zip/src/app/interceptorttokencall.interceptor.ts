import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, tap } from 'rxjs';

@Injectable()
export class InterceptorttokencallInterceptor implements HttpInterceptor {
  xtenant = "fe_0122a"
  token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY0OTY3MzU2NiwiZXhwIjoxNjQ5NzU5OTY2fQ.Y-XVOp2bWbJu8bYFFMc3hHjeZfVTiufMt-Rw5OYFuw4oj_XFwSYNGnKh_OFPNA1ThcSPzw3-syUhZQOQ7_5DhQ"

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    let authreq: HttpRequest<any> = request.clone({
      headers: request.headers.set('Authorization', 'Bearer '
        + 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY1MDYxMzE3MywiZXhwIjoxNjUyNzYwNjU3fQ.c4acV5QLQzuKK0IVjsRpM2JIo6BMBSEEQdGtqaLk3mICK_Mdo5qDzpuWJQIZCbrnmUMHnmtLQ6hlnSylLzJWLg').set("X-TENANT-ID",'fe_0122a')

    });
    return next.handle(authreq);
  }
}
