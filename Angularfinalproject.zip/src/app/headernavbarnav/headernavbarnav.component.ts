import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headernavbarnav',
  templateUrl: './headernavbarnav.component.html',
  styleUrls: ['./headernavbarnav.component.scss']
})
export class HeadernavbarnavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
