import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.scss']
})
export class LoginuserComponent implements OnInit {

username:string="";
password:string="";


valueform(){
this.servicemetod.postdatelogin({username:this.username,password:this.password}).subscribe((resp)=>{
console.log(resp);
localStorage.setItem("user",JSON.stringify(resp));
})
}

  constructor(public servicemetod:ServiceService) { }

  ngOnInit(): void {
  }

}
