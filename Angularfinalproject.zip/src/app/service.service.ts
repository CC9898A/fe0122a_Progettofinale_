import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { logindate } from './models/models';
import { observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Userlist } from './models/userlist';
import { Observable } from 'rxjs';
import { map } from 'rxjs';
import { ReguserComponent } from './reguser/reguser.component';
import { clientlist } from './models/clientlist';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {



  constructor(private http: HttpClient) { }



  postdatelogin(data:logindate) {
    return this.http.post(environment.serverurl+"/api/auth/login",data)









  }

  getuserlist(){
return this.http.get<any>(environment.serverurl+"/api/users")
.pipe(
 map(res=> res.content as Userlist[])
)






  }


  sendregdata(){




  }

  clientdataget(){
return this.http.get<any>(environment.serverurl+"/api/clienti?page=0&size=20&sort=id,ASC")





  }

  facturalget(){
return this.http.get<any>(environment.serverurl+"/api/fatture?page=0&size=20&sort=id,ASC")

  }
}
