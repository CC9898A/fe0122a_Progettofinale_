import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import{ clientlist }from '../models/clientlist'

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {


clientl!:clientlist[]

  constructor(private clntcll:ServiceService) { }

  ngOnInit(): void {

    this.clntcll.clientdataget().subscribe((ress)=>{
      this.clientl=ress.content;




    })


  }




}
