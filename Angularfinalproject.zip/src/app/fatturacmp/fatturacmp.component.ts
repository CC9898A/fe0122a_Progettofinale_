import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { clientlist } from '../models/clientlist';
import { factural } from '../models/fatture';
@Component({
  selector: 'app-fatturacmp',
  templateUrl: './fatturacmp.component.html',
  styleUrls: ['./fatturacmp.component.scss']
})
export class FatturacmpComponent implements OnInit {

 datafact!:factural[]

  constructor(public factcall:ServiceService) { }

  ngOnInit(): void {
    this.factcall.facturalget().subscribe((res)=>{
    this.datafact=res.content

    })

  }

}
