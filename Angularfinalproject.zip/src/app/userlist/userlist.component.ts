import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { observable } from 'rxjs';
import { Observable } from 'rxjs';
import { Userlist } from '../models/userlist';
import { ThisReceiver } from '@angular/compiler';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']
})
export class UserlistComponent implements OnInit {

public datauser:Userlist[]=[]
  constructor(public methdsrv:ServiceService) { }


  ngOnInit(): void {this.methdsrv.getuserlist().subscribe((res:Userlist[])=>{

this.datauser=res;



  })



  }

}

