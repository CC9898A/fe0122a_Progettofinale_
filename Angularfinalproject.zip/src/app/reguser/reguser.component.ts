import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,  } from '@angular/forms';




@Component({
  selector: 'app-reguser',
  templateUrl: './reguser.component.html',
  styleUrls: ['./reguser.component.scss']
})
export class ReguserComponent implements OnInit {
  form!: FormGroup

  user = { username: '', password: '', email: '', role: [] };
  constructor(private fb: FormBuilder,) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      email: new FormControl(""), password: new FormControl(""), username: new FormControl(""), role: new FormControl()


    })





  }


  reguser() {
    this.form.controls["email"]
    this.form.controls["password"]
    this.form.controls["username"]

    console.log()

  }

}


