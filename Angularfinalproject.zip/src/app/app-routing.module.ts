import { Component } from '@angular/core';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientComponent } from './client/client.component';
import { FatturacmpComponent } from './fatturacmp/fatturacmp.component';
import { HomecomponentComponent } from './homecomponent/homecomponent.component';
import { LoginuserComponent } from './loginuser/loginuser.component';
import { ReguserComponent } from './reguser/reguser.component';
import { UserlistComponent } from './userlist/userlist.component';

const routes: Routes = [

  {
    path: "", component: HomecomponentComponent
  },





  {
    path: "accedi", component: LoginuserComponent
  },
  {
    path: "listautenti", component: UserlistComponent
  },
  {
    path: "registrazione", component: ReguserComponent

  },
  {
    path: "listaClienti", component: ClientComponent



  },
  {
    path:"listafatture", component: FatturacmpComponent
  }









];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
